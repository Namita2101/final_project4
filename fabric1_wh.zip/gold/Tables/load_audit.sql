CREATE TABLE [gold].[load_audit] (

	[TableName] varchar(100) NULL, 
	[LoadTimestamp] datetime2(3) NULL, 
	[RowCount] int NULL, 
	[Status] varchar(20) NULL, 
	[Notes] varchar(500) NULL
);

