CREATE TABLE [gold].[profit_classification] (

	[ProductKey] int NULL, 
	[ProfitMargin] float NULL, 
	[ProfitCategory] varchar(50) NULL
);

