CREATE TABLE [gold].[product] (

	[ProductKey] varchar(800) NULL, 
	[Product] varchar(100) NULL, 
	[Standard_Cost] varchar(100) NULL, 
	[Color] varchar(50) NULL, 
	[Subcategory] varchar(100) NULL, 
	[Category] varchar(100) NULL, 
	[Background_Color_Format] varchar(50) NULL, 
	[Font_Color_Format] varchar(50) NULL
);

