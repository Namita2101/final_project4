CREATE TABLE [gold].[monthly_sales] (

	[Year] int NULL, 
	[Month] int NULL, 
	[MonthlySales] float NULL, 
	[OrderCount] int NULL
);

