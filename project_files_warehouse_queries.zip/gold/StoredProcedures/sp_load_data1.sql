CREATE PROCEDURE gold.sp_load_data1
AS
BEGIN
    -- Drop and Create sales_summary Table
    DROP TABLE IF EXISTS gold.sales_summary;
    CREATE TABLE gold.sales_summary (
        ProductKey INT,
        TotalSales FLOAT,
        AvgUnitPrice FLOAT,
        MinSales FLOAT,
        MaxSales FLOAT,
        TotalOrders INT
    );

    -- Insert into sales_summary Table
    INSERT INTO gold.sales_summary
    SELECT
        ProductKey,
        SUM(SalesAmount) AS TotalSales,
        AVG(UnitPrice) AS AvgUnitPrice,
        MIN(SalesAmount) AS MinSales,
        MAX(SalesAmount) AS MaxSales,
        COUNT(*) AS TotalOrders
    FROM gold.sales
    GROUP BY ProductKey;

    -- Drop and Create profit_classification Table
    DROP TABLE IF EXISTS gold.profit_classification;
    CREATE TABLE gold.profit_classification (
        ProductKey INT,
        ProfitMargin FLOAT,
        ProfitCategory VARCHAR(50)
    );

    -- Insert into profit_classification Table
    INSERT INTO gold.profit_classification
    SELECT
        ProductKey,
        (SalesAmount - TotalProductCost) / SalesAmount AS ProfitMargin,
        CASE 
            WHEN (SalesAmount - TotalProductCost) / SalesAmount > 0.3 THEN 'High Profit'
            ELSE 'Low Profit'
        END AS ProfitCategory
    FROM gold.sales
    WHERE SalesAmount != 0;

    -- Drop and Create final_set Table
    DROP TABLE IF EXISTS gold.final_set;
    CREATE TABLE gold.final_set AS
    SELECT 
        s.SalesOrderNumber, 
        s.OrderDate, 
        s.ProductKey, 
        s.SalesTerritoryKey,
        s.OrderQuantity, 
        s.UnitPrice, 
        s.SalesAmount, 
        s.TotalProductCost,
        r.Region, 
        r.Country, 
        r.[Group],
        p.Product, 
        p.Standard_Cost, 
        p.Subcategory
    FROM gold.sales s
    INNER JOIN gold.region r ON r.SalesTerritoryKey = s.SalesTerritoryKey
    INNER JOIN gold.product p ON s.ProductKey = p.ProductKey;

    -- Drop and Create agg_profit Table
    DROP TABLE IF EXISTS gold.agg_profit;
    CREATE TABLE gold.agg_profit AS
    SELECT 
        ProductKey,
        MAX(ProfitMargin) AS ProfitMargin,
        MAX(ProfitCategory) AS ProfitCategory
    FROM gold.profit_classification
    GROUP BY ProductKey;

    -- Drop and Create final_data Table
    DROP TABLE IF EXISTS gold.final_data;
    CREATE TABLE gold.final_data AS
    SELECT 
        f.SalesOrderNumber,
        f.OrderDate,
        f.ProductKey,
        f.SalesTerritoryKey,
        f.OrderQuantity,
        f.UnitPrice,
        f.SalesAmount,
        f.TotalProductCost,
        f.Region,
        f.Country,
        f.[Group],
        f.Product,
        f.Standard_Cost,
        f.Subcategory,
        a.ProfitMargin,
        a.ProfitCategory
    FROM gold.final_set f
    LEFT JOIN gold.agg_profit a ON f.ProductKey = a.ProductKey;

    -- Create and Populate Load Audit Table
    DROP TABLE IF EXISTS gold.load_audit;
    CREATE TABLE gold.load_audit (
        TableName VARCHAR(100),
        LoadTimestamp DATETIME2(3),
        [RowCount] INT,
        Status VARCHAR(20),
        Notes VARCHAR(500)
    );

    -- Audit for profit_classification
    INSERT INTO gold.load_audit
    SELECT
        'profit_classification',
        SYSDATETIME(),
        COUNT(*),
        'Success',
        'Loaded successfully'
    FROM gold.profit_classification;

    -- Audit for sales_summary
    INSERT INTO gold.load_audit
    SELECT
        'sales_summary',
        SYSDATETIME(),
        COUNT(*),
        'Success',
        'Loaded successfully'
    FROM gold.sales_summary;

    -- Audit for final_set
    INSERT INTO gold.load_audit
    SELECT
        'final_set',
        SYSDATETIME(),
        COUNT(*),
        'Success',
        'Joined product, sales, and region'
    FROM gold.final_set;

    -- Audit for agg_profit
    INSERT INTO gold.load_audit
    SELECT
        'agg_profit',
        SYSDATETIME(),
        COUNT(*),
        'Success',
        'Picked one profit row per ProductKey using aggregation'
    FROM gold.agg_profit;

    -- Audit for final_data
    INSERT INTO gold.load_audit
    SELECT
        'final_data',
        SYSDATETIME(),
        COUNT(*),
        'Success',
        'Joined final_set and profit_classification; this is Power BI ready'
    FROM gold.final_data;
END;