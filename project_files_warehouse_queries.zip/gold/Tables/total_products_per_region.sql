CREATE TABLE [gold].[total_products_per_region] (

	[Region] varchar(100) NULL, 
	[cnt_prokey_region] int NULL
);