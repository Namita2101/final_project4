CREATE TABLE [gold].[sales] (

	[SalesOrderNumber] varchar(50) NULL, 
	[OrderDate] date NULL, 
	[ProductKey] int NULL, 
	[SalesTerritoryKey] int NULL, 
	[OrderQuantity] int NULL, 
	[UnitPrice] float NULL, 
	[SalesAmount] float NULL, 
	[TotalProductCost] float NULL
);