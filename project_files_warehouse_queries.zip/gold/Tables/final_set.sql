CREATE TABLE [gold].[final_set] (

	[SalesOrderNumber] varchar(50) NULL, 
	[OrderDate] date NULL, 
	[ProductKey] int NULL, 
	[SalesTerritoryKey] int NULL, 
	[OrderQuantity] int NULL, 
	[UnitPrice] float NULL, 
	[SalesAmount] float NULL, 
	[TotalProductCost] float NULL, 
	[Region] varchar(100) NULL, 
	[Country] varchar(100) NULL, 
	[Group] varchar(100) NULL, 
	[Product] varchar(100) NULL, 
	[Standard_Cost] varchar(100) NULL, 
	[Subcategory] varchar(100) NULL
);