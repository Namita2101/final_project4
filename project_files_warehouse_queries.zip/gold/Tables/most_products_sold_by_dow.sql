CREATE TABLE [gold].[most_products_sold_by_dow] (

	[OrderDate] date NULL, 
	[day_of_week] varchar(50) NULL, 
	[pro_cnt] int NULL
);