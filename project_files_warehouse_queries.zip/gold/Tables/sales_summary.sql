CREATE TABLE [gold].[sales_summary] (

	[ProductKey] int NULL, 
	[TotalSales] float NULL, 
	[AvgUnitPrice] float NULL, 
	[MinSales] float NULL, 
	[MaxSales] float NULL, 
	[TotalOrders] int NULL
);