CREATE TABLE [gold].[region] (

	[SalesTerritoryKey] varchar(100) NULL, 
	[Region] varchar(100) NULL, 
	[Country] varchar(100) NULL, 
	[Group] varchar(100) NULL
);