CREATE TABLE [gold].[agg_profit] (

	[ProductKey] int NULL, 
	[ProfitMargin] float NULL, 
	[ProfitCategory] varchar(50) NULL
);