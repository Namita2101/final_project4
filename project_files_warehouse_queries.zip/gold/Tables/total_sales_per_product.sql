CREATE TABLE [gold].[total_sales_per_product] (

	[ProductKey] int NULL, 
	[tot_sum_sales] float NULL
);